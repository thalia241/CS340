# Example Python Code to Insert a Document 

from pymongo import MongoClient
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'Password123' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient(f"mongodb://{USER}:{PASS}@{HOST}:{PORT}/?authSource=admin")
        self.database = self.client[DB]
        self.collection = self.database[COL] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if not isinstance(data, dict) or not data:
            return False
        try:
            result = self.collection.insert_one(data)  # modern API
            return bool(result.inserted_id)
        except errors.PyMongoError:
            return False 
            

    # Create method to implement the R in CRUD.
    def read(self, query):
        if query is None:
            query = {}
        if not isinstance(query, dict):
            return []
        try:
            cursor = self.collection.find(query, {"_id": False})
            return list(cursor)
        except errors.PyMongoError:
            return []
        
    # Create method to implement the U in CRUD.
    def update(self, query, new_values):
        # Updates matching documents and returns count of modified documents.
        if not isinstance(query, dict) or not isinstance(new_values, dict):
            return 0
        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except errors.PyMongoError:
            return 0
    
    # Create method to implement the D in CRUD.
    def delete(self, query):
        # Deletes matching documents and returns count of deleted documents.
        if not isinstance(query, dict):
            return 0
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except errors.PyMongoError:
            return 0 